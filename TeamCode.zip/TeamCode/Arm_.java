import java.util.*;

/**
 * To be written still
 * This is skeleton code based on UML from 9/11/2019
 */
public class Arm_ {

    /**
     * Default constructor
     */
    public Arm_() {
    }

    /**
     * 
     */
    private double armLength1;

    /**
     * 
     */
    private double armLength2;

    /**
     * 
     */
    private double angle1;

    /**
     * 
     */
    private double angle2;

    /**
     * 
     */
    private DcMotor motor1;

    /**
     * 
     */
    private DcMotor motor2;

    /**
     * 
     */
    private Servo claw;

    /**
     * 
     */
    private Servo wrist;

    /**
     * 
     */
    private Servo twist;


    /**
     * @param HardwareMap hm 
     * @param double armlen1 
     * @param double armlen2 
     * @param double lowestY
     */
    public void Arm_(void HardwareMap hm, void double armlen1, void double armlen2, void double lowestY) {
        // TODO implement here
    }

    /**
     * @param double x 
     * @param double y 
     * @param double speed
     */
    public void setPositionCoords(void double x, void double y, void double speed) {
        // TODO implement here
    }

    /**
     * @param double angle1 
     * @param double angle 2
     */
    public void setPositionAngles(void double angle1, void double angle 2) {
        // TODO implement here
    }

    /**
     * @param boolean open
     */
    public void adjustClaw(void boolean open) {
        // TODO implement here
    }

}